# Smart Study Planner

A final year BCA Android project built with Kotlin and Jetpack Compose.

## Features
- ✅ Add / Edit / Delete study tasks
- ✅ Deadline selection with DatePicker & TimePicker
- ✅ Room Database for persistent storage
- ✅ Notification reminders (1 hour before deadline)
- ✅ Calendar view showing tasks per day
- ✅ Dark mode toggle
- ✅ Progress tracker with stats

## Setup Instructions

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 11+
- Android SDK API 24+

### Steps
1. Open Android Studio
2. Click **File → Open** and select the `SmartStudyPlanner` folder
3. Wait for Gradle sync to complete (it will download dependencies automatically)
4. Click **Run ▶** or press `Shift+F10` to build and run on emulator/device

### Minimum SDK
- API 24 (Android 7.0)

### Tech Stack
- **Language**: Kotlin
- **UI**: Jetpack Compose + Material 3
- **Database**: Room (SQLite)
- **Architecture**: MVVM (ViewModel + Repository)
- **Notifications**: AlarmManager + BroadcastReceiver
- **Navigation**: Navigation Compose

## Project Structure
```
com.example.smartstudyplanner/
├── MainActivity.kt         - Entry point & navigation graph
├── TaskEntity.kt           - Room database entity
├── TaskDao.kt              - Database access object
├── AppDatabase.kt          - Room database singleton
├── TaskRepository.kt       - Data layer abstraction
├── TaskViewModel.kt        - UI state & business logic
├── NotificationHelper.kt   - Alarm scheduling
├── NotificationReceiver.kt - Broadcast receiver for alarms
├── BootReceiver.kt         - Reschedule alarms after reboot
├── HomeScreen.kt           - Task list with tabs
├── AddEditTaskScreen.kt    - Add/edit form
├── CalendarScreen.kt       - Monthly calendar view
├── ProgressScreen.kt       - Statistics & progress
└── ui/theme/Theme.kt       - Material3 light/dark theme
```
