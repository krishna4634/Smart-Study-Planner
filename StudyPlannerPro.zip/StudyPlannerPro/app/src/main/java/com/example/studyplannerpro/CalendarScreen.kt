package com.example.studyplannerpro

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

data class CalDay(val day: Int, val month: Int, val year: Int)

fun buildGrid(cal: Calendar): List<CalDay> {
    val r = mutableListOf<CalDay>()
    val first = Calendar.getInstance().apply { set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 1) }
    val startDow = first.get(Calendar.DAY_OF_WEEK) - 1
    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    repeat(startDow) { r.add(CalDay(0, 0, 0)) }
    for (d in 1..daysInMonth) r.add(CalDay(d, cal.get(Calendar.MONTH), cal.get(Calendar.YEAR)))
    while (r.size % 7 != 0) r.add(CalDay(0, 0, 0))
    return r
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarScreen(viewModel: TaskViewModel, onBack: () -> Unit, onEditTask: (Int) -> Unit) {
    val today   = Calendar.getInstance()
    var curMon  by remember { mutableStateOf(Calendar.getInstance()) }
    var selDate by remember { mutableStateOf(today) }
    val ui      by viewModel.uiState.collectAsState()

    val selStart = Calendar.getInstance().apply {
        timeInMillis = selDate.timeInMillis; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
    }.timeInMillis
    val dayTasks = ui.allTasks.filter { it.deadlineMillis in selStart..(selStart + 86400000 - 1) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = { Text("Calendar", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background))
        }
    ) { pv ->
        Column(Modifier.fillMaxSize().padding(pv)) {

            // ── Month card ────────────────────────────────────────────────────
            Card(Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.padding(16.dp)) {
                    // Month nav
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        IconButton(onClick = {
                            curMon = Calendar.getInstance().apply { timeInMillis = curMon.timeInMillis; add(Calendar.MONTH, -1) }
                        }) { Icon(Icons.Default.ChevronLeft, null) }
                        Text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(curMon.time),
                            fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        IconButton(onClick = {
                            curMon = Calendar.getInstance().apply { timeInMillis = curMon.timeInMillis; add(Calendar.MONTH, 1) }
                        }) { Icon(Icons.Default.ChevronRight, null) }
                    }
                    // Day headers
                    Row(Modifier.fillMaxWidth()) {
                        listOf("Su","Mo","Tu","We","Th","Fr","Sa").forEach { d ->
                            Text(d, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp,
                                fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    // Grid
                    val grid = buildGrid(curMon)
                    LazyVerticalGrid(GridCells.Fixed(7), Modifier.fillMaxWidth().height(220.dp), userScrollEnabled = false) {
                        items(grid.size) { idx ->
                            val d = grid[idx]
                            val isSel  = d.day == selDate.get(Calendar.DAY_OF_MONTH) && d.month == selDate.get(Calendar.MONTH) && d.year == selDate.get(Calendar.YEAR)
                            val isTdy  = d.day == today.get(Calendar.DAY_OF_MONTH) && d.month == today.get(Calendar.MONTH) && d.year == today.get(Calendar.YEAR)
                            val hasTsk = ui.allTasks.any { t ->
                                val c = Calendar.getInstance().apply { timeInMillis = t.deadlineMillis }
                                c.get(Calendar.DAY_OF_MONTH) == d.day && c.get(Calendar.MONTH) == d.month && c.get(Calendar.YEAR) == d.year
                            }
                            Box(Modifier.aspectRatio(1f).padding(2.dp).clip(CircleShape)
                                .background(when {
                                    isSel -> MaterialTheme.colorScheme.primary
                                    isTdy -> MaterialTheme.colorScheme.primaryContainer
                                    else  -> Color.Transparent
                                })
                                .clickable(enabled = d.day > 0) {
                                    selDate = Calendar.getInstance().apply { set(d.year, d.month, d.day) }
                                }, contentAlignment = Alignment.Center) {
                                if (d.day > 0) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(d.day.toString(), fontSize = 13.sp,
                                        fontWeight = if (isSel || isTdy) FontWeight.Bold else FontWeight.Normal,
                                        color = when { isSel -> Color.White; isTdy -> MaterialTheme.colorScheme.primary; else -> MaterialTheme.colorScheme.onSurface })
                                    if (hasTsk) Box(Modifier.size(4.dp).clip(CircleShape)
                                        .background(if (isSel) Color.White.copy(0.7f) else MaterialTheme.colorScheme.primary))
                                }
                            }
                        }
                    }
                }
            }

            // ── Day task list ─────────────────────────────────────────────────
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(SimpleDateFormat("EEE, MMMM d", Locale.getDefault()).format(selDate.time),
                    fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                if (dayTasks.isNotEmpty()) {
                    Spacer(Modifier.width(8.dp))
                    Badge(containerColor = MaterialTheme.colorScheme.primary) { Text("${dayTasks.size}") }
                }
            }

            if (dayTasks.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📭", fontSize = 44.sp)
                        Text("No tasks on this day", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(dayTasks) { task ->
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(1.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.width(4.dp).height(40.dp).clip(RoundedCornerShape(2.dp))
                                    .background(priorityColor(task.priority)))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(task.title, fontWeight = FontWeight.Medium, fontSize = 14.sp, maxLines = 1)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date(task.deadlineMillis)),
                                            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        if (task.subject.isNotBlank()) {
                                            Text("  ·  ${task.subject}", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                                Box(Modifier.clip(RoundedCornerShape(8.dp))
                                    .background(taskStatusColor(task.status).copy(0.12f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text(taskStatusLabel(task.status), fontSize = 10.sp,
                                        color = taskStatusColor(task.status), fontWeight = FontWeight.Medium)
                                }
                                IconButton(onClick = { onEditTask(task.id) }, modifier = Modifier.size(34.dp)) {
                                    Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(16.dp)) }
                }
            }
        }
    }
}
