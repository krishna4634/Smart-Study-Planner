package com.example.studyplannerpro

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studyplannerpro.ui.theme.AppColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen(viewModel: TaskViewModel, onBack: () -> Unit) {
    val s       by viewModel.uiState.collectAsState()
    val total   = s.totalCount
    val done    = s.completedCount
    val inProg  = s.inProgressCount
    val pending = (total - done - inProg).coerceAtLeast(0)
    val overdue = s.overdueCount
    val prog    = if (total > 0) done.toFloat() / total else 0f
    val totalHrs  = s.allTasks.sumOf { it.estimatedHours.toDouble() }
    val doneHrs   = s.completedTasks.sumOf { it.estimatedHours.toDouble() }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(title = { Text("Progress", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background))
        }
    ) { pv ->
        Column(Modifier.fillMaxSize().padding(pv).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {

            // Progress ring card
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp)) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Overall Progress", fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                        modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(progress = { prog }, modifier = Modifier.size(110.dp),
                                strokeWidth = 9.dp, color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant)
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${(prog * 100).toInt()}%", fontSize = 24.sp, fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary)
                                Text("done", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        Spacer(Modifier.width(24.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            LegendRow("Done",        done,    AppColors.Green500)
                            LegendRow("In Progress", inProg,  AppColors.Primary500)
                            LegendRow("Pending",     pending, AppColors.Amber500)
                            if (overdue > 0) LegendRow("Overdue", overdue, AppColors.Red500)
                        }
                    }
                }
            }

            // 4 stat chips
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("$total",  "Total",    MaterialTheme.colorScheme.primary,   MaterialTheme.colorScheme.primaryContainer, Modifier.weight(1f))
                StatCard("$done",   "Done",     AppColors.Green500,                  AppColors.Green100,    Modifier.weight(1f))
                StatCard("$inProg", "In Prog",  AppColors.Primary500,                AppColors.Primary100,  Modifier.weight(1f))
                StatCard("$overdue","Late",     AppColors.Red500,                    AppColors.Red100,      Modifier.weight(1f))
            }

            // Hours
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(2.dp)) {
                Row(Modifier.fillMaxWidth().padding(16.dp), Arrangement.SpaceEvenly, Alignment.CenterVertically) {
                    HoursCol("${totalHrs.toInt()}h", "Total Hours", MaterialTheme.colorScheme.onSurface)
                    Divider(Modifier.width(1.dp).height(40.dp), color = MaterialTheme.colorScheme.outline.copy(0.3f))
                    HoursCol("${doneHrs.toInt()}h", "Studied",     AppColors.Green500)
                    Divider(Modifier.width(1.dp).height(40.dp), color = MaterialTheme.colorScheme.outline.copy(0.3f))
                    HoursCol("${(totalHrs - doneHrs).coerceAtLeast(0.0).toInt()}h", "Remaining", AppColors.Amber500)
                }
            }

            // Status bar breakdown
            BreakdownCard("Status Breakdown") {
                PBar("Done",        done,    total, AppColors.Green500)
                PBar("In Progress", inProg,  total, AppColors.Primary500)
                PBar("Pending",     pending, total, AppColors.Amber500)
            }

            // Priority breakdown
            val high = s.allTasks.count { it.priority == Priority.HIGH }
            val med  = s.allTasks.count { it.priority == Priority.MEDIUM }
            val low  = s.allTasks.count { it.priority == Priority.LOW }
            BreakdownCard("Priority Breakdown") {
                PBar("🔴 High",   high, total, AppColors.Red500)
                PBar("🟡 Medium", med,  total, AppColors.Amber500)
                PBar("🟢 Low",    low,  total, AppColors.Green500)
            }

            // Subject breakdown
            val subjects = s.allTasks.filter { it.subject.isNotBlank() }.groupBy { it.subject }
            if (subjects.isNotEmpty()) {
                BreakdownCard("By Subject") {
                    subjects.forEach { (subj, tasks) ->
                        val d2   = tasks.count { it.status == TaskStatus.COMPLETED }
                        val frac = if (tasks.isNotEmpty()) d2.toFloat() / tasks.size else 0f
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(subj, modifier = Modifier.width(110.dp), fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface)
                            LinearProgressIndicator(progress = { frac }, modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
                                color = MaterialTheme.colorScheme.primary,
                                trackColor = MaterialTheme.colorScheme.surfaceVariant)
                            Spacer(Modifier.width(8.dp))
                            Text("$d2/${tasks.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }
            }

            if (overdue > 0) {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = AppColors.Red100)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("⚠️", fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("$overdue Overdue Task${if (overdue > 1) "s" else ""}", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = AppColors.Red600)
                            Text("These need immediate attention!", fontSize = 12.sp, color = AppColors.Red600.copy(0.8f))
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable fun LegendRow(label: String, count: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text("$count $label", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable fun StatCard(value: String, label: String, color: Color, bg: Color, modifier: Modifier) {
    Card(modifier.height(70.dp), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = color)
            Text(label, fontSize = 9.sp, color = color.copy(0.8f))
        }
    }
}

@Composable fun HoursCol(value: String, label: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = color)
        Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable fun BreakdownCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.padding(bottom = 12.dp))
            content()
        }
    }
}

@Composable fun PBar(label: String, count: Int, total: Int, color: Color) {
    val frac = if (total > 0) count.toFloat() / total else 0f
    Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(100.dp), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LinearProgressIndicator(progress = { frac }, modifier = Modifier.weight(1f).height(7.dp).clip(CircleShape),
            color = color, trackColor = MaterialTheme.colorScheme.surfaceVariant)
        Spacer(Modifier.width(8.dp))
        Text("$count", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = color)
    }
}
