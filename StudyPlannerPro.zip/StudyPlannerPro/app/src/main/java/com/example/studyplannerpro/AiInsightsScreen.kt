package com.example.studyplannerpro

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studyplannerpro.ui.theme.AppColors
import java.util.concurrent.TimeUnit

data class Insight(val type: InsightType, val emoji: String, val title: String, val message: String, val actionLabel: String? = null)
enum class InsightType { WARNING, TIP, PRAISE, INFO }

fun generateInsights(tasks: List<TaskEntity>): List<Insight> {
    val out  = mutableListOf<Insight>()
    val now  = System.currentTimeMillis()
    val day  = TimeUnit.DAYS.toMillis(1)

    if (tasks.isEmpty()) {
        out += Insight(InsightType.INFO, "📋", "No tasks yet", "Add your first study task to get started.", "Add Task")
        return out
    }
    val total = tasks.size; val done = tasks.count { it.status == TaskStatus.COMPLETED }
    val inP = tasks.count { it.status == TaskStatus.IN_PROGRESS }; val pend = tasks.count { it.status == TaskStatus.PENDING }
    val overdue = tasks.filter { it.deadlineMillis < now && it.status != TaskStatus.COMPLETED }
    val soon    = tasks.filter { it.deadlineMillis in now..(now + day) && it.status != TaskStatus.COMPLETED }
    val highPri = tasks.filter { it.priority == Priority.HIGH && it.status != TaskStatus.COMPLETED }
    val rate    = if (total > 0) done.toFloat() / total else 0f

    if (overdue.isNotEmpty()) out += Insight(InsightType.WARNING, "🚨", "${overdue.size} Overdue Task(s)", "\"${overdue.first().title}\" is past due. Tackle it now!")
    if (soon.isNotEmpty())    out += Insight(InsightType.WARNING, "⏰", "Due in 24 Hours", "${soon.size} task(s) due soon — don't forget!")
    if (inP > 3)              out += Insight(InsightType.TIP, "🎯", "Too Many In Progress", "You have $inP tasks in progress. Try to focus on 2–3 at a time.")
    if (highPri.size >= 2)    out += Insight(InsightType.WARNING, "🔴", "${highPri.size} High-Priority Tasks", "\"${highPri.first().title}\" needs your attention most.")
    if (rate >= 0.75f && total >= 4) out += Insight(InsightType.PRAISE, "🌟", "Outstanding Progress!", "You've completed ${(rate * 100).toInt()}% of your tasks. Keep it up!")
    else if (rate >= 0.5f && total >= 3) out += Insight(InsightType.PRAISE, "👍", "Halfway There!", "$done of $total tasks done. Great momentum!")
    if (inP == 0 && pend > 0) out += Insight(InsightType.TIP, "🚀", "Nothing Started", "You have $pend pending tasks. Pick one and get started!")
    val hrs = tasks.filter { it.status != TaskStatus.COMPLETED }.sumOf { it.estimatedHours.toDouble() }
    if (hrs > 20) out += Insight(InsightType.WARNING, "📚", "Heavy Workload", "~${hrs.toInt()} hours of study remain. Break it into daily sessions.")
    if (done == total && total > 0) out += Insight(InsightType.PRAISE, "🎉", "All Completed!", "Every task is done — amazing work!")
    return out
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiInsightsScreen(viewModel: TaskViewModel, onBack: () -> Unit, onAddTask: () -> Unit) {
    val state    by viewModel.uiState.collectAsState()
    val insights = remember(state.allTasks) { generateInsights(state.allTasks) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("AI Insights", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pv ->
        LazyColumn(Modifier.fillMaxSize().padding(pv),
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {

            item {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🧠", fontSize = 32.sp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Personalised Analysis", fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text("Based on ${state.totalCount} tasks · ${insights.size} suggestions",
                                fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(0.7f))
                        }
                    }
                }
            }

            items(insights) { insight -> InsightCard(insight, onAddTask) }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun InsightCard(insight: Insight, onAddTask: () -> Unit) {
    val (bg, border) = when (insight.type) {
        InsightType.WARNING -> AppColors.Amber100 to AppColors.Amber500
        InsightType.TIP     -> AppColors.Primary100 to AppColors.Primary500
        InsightType.PRAISE  -> AppColors.Green100 to AppColors.Green500
        InsightType.INFO    -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.outline
    }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        elevation = CardDefaults.cardElevation(1.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(border.copy(0.15f)),
                contentAlignment = Alignment.Center) {
                Text(insight.emoji, fontSize = 20.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(insight.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = AppColors.TextDark)
                Spacer(Modifier.height(3.dp))
                Text(insight.message, fontSize = 13.sp, color = AppColors.TextMuted, lineHeight = 18.sp)
                if (insight.actionLabel == "Add Task") {
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = onAddTask, contentPadding = PaddingValues(0.dp)) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add Task", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
