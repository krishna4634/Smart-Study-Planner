package com.example.studyplannerpro.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

object AppColors {
    val Primary600 = Color(0xFF1D4ED8)
    val Primary500 = Color(0xFF3B82F6)
    val Primary400 = Color(0xFF60A5FA)
    val Primary100 = Color(0xFFDBEAFE)
    val Primary50  = Color(0xFFEFF6FF)

    val Green600   = Color(0xFF059669)
    val Green500   = Color(0xFF10B981)
    val Green100   = Color(0xFFD1FAE5)

    val Red600     = Color(0xFFDC2626)
    val Red500     = Color(0xFFEF4444)
    val Red100     = Color(0xFFFEE2E2)

    val Amber600   = Color(0xFFD97706)
    val Amber500   = Color(0xFFF59E0B)
    val Amber100   = Color(0xFFFEF3C7)

    val Surface800 = Color(0xFF1E293B)
    val Surface700 = Color(0xFF334155)
    val Surface600 = Color(0xFF475569)

    val LightBg    = Color(0xFFF8FAFC)
    val LightCard  = Color(0xFFFFFFFF)
    val LightCard2 = Color(0xFFF1F5F9)

    val TextDark   = Color(0xFF0F172A)
    val TextMuted  = Color(0xFF64748B)
    val TextLight  = Color(0xFFCBD5E1)
}

private val DarkColorScheme = darkColorScheme(
    primary              = AppColors.Primary400,
    onPrimary            = Color.White,
    primaryContainer     = Color(0xFF1E3A5F),
    onPrimaryContainer   = AppColors.Primary100,
    secondary            = AppColors.Green500,
    onSecondary          = Color.White,
    background           = Color(0xFF0F172A),
    onBackground         = Color(0xFFE2E8F0),
    surface              = AppColors.Surface800,
    onSurface            = Color(0xFFE2E8F0),
    surfaceVariant       = AppColors.Surface700,
    onSurfaceVariant     = AppColors.TextLight,
    outline              = AppColors.Surface600,
    error                = AppColors.Red500,
    onError              = Color.White,
)

private val LightColorScheme = lightColorScheme(
    primary              = AppColors.Primary500,
    onPrimary            = Color.White,
    primaryContainer     = AppColors.Primary50,
    onPrimaryContainer   = AppColors.Primary600,
    secondary            = AppColors.Green500,
    onSecondary          = Color.White,
    background           = AppColors.LightBg,
    onBackground         = AppColors.TextDark,
    surface              = AppColors.LightCard,
    onSurface            = AppColors.TextDark,
    surfaceVariant       = AppColors.LightCard2,
    onSurfaceVariant     = AppColors.TextMuted,
    outline              = Color(0xFFE2E8F0),
    error                = AppColors.Red500,
    onError              = Color.White,
)

val AppTypography = Typography(
    headlineLarge  = TextStyle(fontWeight = FontWeight.Bold,    fontSize = 28.sp, lineHeight = 36.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold,fontSize = 24.sp, lineHeight = 32.sp),
    headlineSmall  = TextStyle(fontWeight = FontWeight.SemiBold,fontSize = 20.sp, lineHeight = 28.sp),
    titleLarge     = TextStyle(fontWeight = FontWeight.SemiBold,fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium    = TextStyle(fontWeight = FontWeight.Medium,  fontSize = 16.sp, lineHeight = 22.sp),
    titleSmall     = TextStyle(fontWeight = FontWeight.Medium,  fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge      = TextStyle(fontWeight = FontWeight.Normal,  fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium     = TextStyle(fontWeight = FontWeight.Normal,  fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall      = TextStyle(fontWeight = FontWeight.Normal,  fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge     = TextStyle(fontWeight = FontWeight.Medium,  fontSize = 14.sp, lineHeight = 20.sp),
    labelMedium    = TextStyle(fontWeight = FontWeight.Medium,  fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall     = TextStyle(fontWeight = FontWeight.Medium,  fontSize = 11.sp, lineHeight = 16.sp),
)

@Composable
fun StudyPlannerProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = android.graphics.Color.TRANSPARENT
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }
    MaterialTheme(colorScheme = colorScheme, typography = AppTypography, content = content)
}
