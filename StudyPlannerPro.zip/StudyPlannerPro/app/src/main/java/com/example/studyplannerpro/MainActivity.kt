package com.example.studyplannerpro

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.*
import androidx.navigation.compose.*
import com.example.studyplannerpro.ui.theme.StudyPlannerProTheme

class MainActivity : ComponentActivity() {
    private val requestPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            requestPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        setContent {
            var isDarkMode by remember { mutableStateOf(false) }
            StudyPlannerProTheme(darkTheme = isDarkMode) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    AppNavigation(
                        taskViewModel = viewModel(), authViewModel = viewModel(),
                        isDarkMode = isDarkMode, onToggleDarkMode = { isDarkMode = !isDarkMode }
                    )
                }
            }
        }
    }
}

@Composable
fun AppNavigation(
    taskViewModel: TaskViewModel, authViewModel: AuthViewModel,
    isDarkMode: Boolean, onToggleDarkMode: () -> Unit
) {
    val nav   = rememberNavController()
    val auth  by authViewModel.uiState.collectAsState()
    val start = if (auth.isLoggedIn) "dashboard" else "login"

    NavHost(nav, startDestination = start) {
        composable("login") {
            LoginScreen(authViewModel) { nav.navigate("register") { launchSingleTop = true } }
            LaunchedEffect(auth.isLoggedIn) {
                if (auth.isLoggedIn) nav.navigate("dashboard") { popUpTo("login") { inclusive = true } }
            }
        }
        composable("register") {
            RegisterScreen(authViewModel) { nav.navigate("login") { popUpTo("register") { inclusive = true } } }
        }
        composable("dashboard") {
            DashboardScreen(authViewModel, taskViewModel, isDarkMode, onToggleDarkMode,
                onAddTask    = { nav.navigate("add_task") },
                onViewTasks  = { nav.navigate("home") },
                onCalendar   = { nav.navigate("calendar") },
                onProgress   = { nav.navigate("progress") },
                onAiInsights = { nav.navigate("ai_insights") },
                onLogout     = { nav.navigate("login") { popUpTo(0) { inclusive = true } } })
        }
        composable("home") {
            HomeScreen(taskViewModel, isDarkMode, onToggleDarkMode,
                onAddTask      = { nav.navigate("add_task") },
                onEditTask     = { nav.navigate("edit_task/$it") },
                onCalendarView = { nav.navigate("calendar") },
                onProgressView = { nav.navigate("progress") })
        }
        composable("add_task") {
            AddEditTaskScreen(taskViewModel, null) { nav.popBackStack() }
        }
        composable("edit_task/{taskId}", arguments = listOf(navArgument("taskId") { type = NavType.IntType })) { back ->
            AddEditTaskScreen(taskViewModel, back.arguments?.getInt("taskId")) { nav.popBackStack() }
        }
        composable("calendar") {
            CalendarScreen(taskViewModel, onBack = { nav.popBackStack() }, onEditTask = { nav.navigate("edit_task/$it") })
        }
        composable("progress") {
            ProgressScreen(taskViewModel) { nav.popBackStack() }
        }
        composable("ai_insights") {
            AiInsightsScreen(taskViewModel, onBack = { nav.popBackStack() }, onAddTask = { nav.navigate("add_task") })
        }
    }
}
