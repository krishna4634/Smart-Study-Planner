package com.example.studyplannerpro

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {

    // ── Basic queries ────────────────────────────────────────────────────────
    @Query("SELECT * FROM tasks ORDER BY deadlineMillis ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTaskById(id: Int): TaskEntity?

    // ── Module 4: Status-based queries ───────────────────────────────────────
    @Query("SELECT * FROM tasks WHERE status = 'PENDING' ORDER BY deadlineMillis ASC")
    fun getPendingTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE status = 'IN_PROGRESS' ORDER BY deadlineMillis ASC")
    fun getInProgressTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE status = 'COMPLETED' ORDER BY deadlineMillis DESC")
    fun getCompletedTasks(): Flow<List<TaskEntity>>

    // Legacy: kept so existing code compiles
    @Query("SELECT * FROM tasks WHERE isCompleted = 0 ORDER BY deadlineMillis ASC")
    fun getLegacyPendingTasks(): Flow<List<TaskEntity>>

    // ── Module 6: Calendar queries ───────────────────────────────────────────
    @Query("SELECT * FROM tasks WHERE deadlineMillis BETWEEN :start AND :end ORDER BY deadlineMillis ASC")
    fun getTasksForDateRange(start: Long, end: Long): Flow<List<TaskEntity>>

    // ── Module 9: Search & Filter ────────────────────────────────────────────
    @Query("""
        SELECT * FROM tasks 
        WHERE (title LIKE '%' || :query || '%' 
            OR description LIKE '%' || :query || '%'
            OR subject LIKE '%' || :query || '%'
            OR tags LIKE '%' || :query || '%')
        ORDER BY deadlineMillis ASC
    """)
    fun searchTasks(query: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE priority = :priority ORDER BY deadlineMillis ASC")
    fun getTasksByPriority(priority: Priority): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE subject = :subject ORDER BY deadlineMillis ASC")
    fun getTasksBySubject(subject: String): Flow<List<TaskEntity>>

    @Query("SELECT DISTINCT subject FROM tasks WHERE subject != '' ORDER BY subject ASC")
    fun getAllSubjects(): Flow<List<String>>

    // ── CRUD operations ──────────────────────────────────────────────────────
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Int)

    @Query("UPDATE tasks SET status = :status, isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateTaskStatus(id: Int, status: TaskStatus, isCompleted: Boolean, updatedAt: Long)

    // ── Module 3: Analytics counts ───────────────────────────────────────────
    @Query("SELECT COUNT(*) FROM tasks")
    fun getTotalTaskCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE status = 'COMPLETED'")
    fun getCompletedTaskCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE status = 'IN_PROGRESS'")
    fun getInProgressCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM tasks WHERE deadlineMillis < :now AND status != 'COMPLETED'")
    fun getOverdueCount(now: Long): Flow<Int>

    // Tasks due within next 24 hours and not completed
    @Query("SELECT * FROM tasks WHERE deadlineMillis BETWEEN :now AND :tomorrow AND status != 'COMPLETED' ORDER BY deadlineMillis ASC")
    fun getTasksDueSoon(now: Long, tomorrow: Long): Flow<List<TaskEntity>>
}
