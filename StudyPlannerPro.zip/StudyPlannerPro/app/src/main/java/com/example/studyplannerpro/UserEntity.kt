package com.example.studyplannerpro

import androidx.room.Entity
import androidx.room.PrimaryKey

// Stores registered users in the local Room database
@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val username: String,       // Must be unique
    val password: String,       // Stored as plain text (OK for BCA project)
    val fullName: String,
    val createdAt: Long = System.currentTimeMillis()
)
