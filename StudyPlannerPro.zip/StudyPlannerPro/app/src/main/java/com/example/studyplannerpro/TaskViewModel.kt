package com.example.studyplannerpro

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// ── UI State ─────────────────────────────────────────────────────────────────
data class TaskUiState(
    val allTasks: List<TaskEntity>        = emptyList(),
    val pendingTasks: List<TaskEntity>    = emptyList(),
    val inProgressTasks: List<TaskEntity> = emptyList(),
    val completedTasks: List<TaskEntity>  = emptyList(),
    val dueSoonTasks: List<TaskEntity>    = emptyList(),
    val totalCount: Int   = 0,
    val completedCount: Int = 0,
    val inProgressCount: Int = 0,
    val overdueCount: Int = 0,
    val allSubjects: List<String> = emptyList(),
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

// ── Filter State (Module 9) ───────────────────────────────────────────────────
data class FilterState(
    val searchQuery: String = "",
    val selectedPriority: Priority? = null,
    val selectedSubject: String? = null,
    val selectedStatus: TaskStatus? = null,
    val showOverdueOnly: Boolean = false
)

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class TaskViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: TaskRepository
    private val notificationHelper: NotificationHelper

    private val _uiState = MutableStateFlow(TaskUiState())
    val uiState: StateFlow<TaskUiState> = _uiState.asStateFlow()

    // Module 9: Search & Filter
    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    // Filtered task list derived from allTasks + filterState
    val filteredTasks: StateFlow<List<TaskEntity>> = combine(
        _uiState.map { it.allTasks },
        _filterState
    ) { tasks, filter ->
        var result = tasks

        // Text search
        if (filter.searchQuery.isNotBlank()) {
            val q = filter.searchQuery.lowercase()
            result = result.filter { task ->
                task.title.lowercase().contains(q) ||
                task.description.lowercase().contains(q) ||
                task.subject.lowercase().contains(q) ||
                task.tags.lowercase().contains(q)
            }
        }
        // Priority filter
        if (filter.selectedPriority != null) {
            result = result.filter { it.priority == filter.selectedPriority }
        }
        // Subject filter
        if (filter.selectedSubject != null) {
            result = result.filter { it.subject == filter.selectedSubject }
        }
        // Status filter
        if (filter.selectedStatus != null) {
            result = result.filter { it.status == filter.selectedStatus }
        }
        // Overdue only
        if (filter.showOverdueOnly) {
            val now = System.currentTimeMillis()
            result = result.filter { it.deadlineMillis < now && it.status != TaskStatus.COMPLETED }
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        val database = AppDatabase.getDatabase(application)
        repository = TaskRepository(database.taskDao())
        notificationHelper = NotificationHelper(application)

        val now = System.currentTimeMillis()
        val tomorrow = now + 24 * 60 * 60 * 1000L

        viewModelScope.launch {
            combine(
                repository.allTasks,
                repository.pendingTasks,
                repository.inProgressTasks,
                repository.completedTasks,
                repository.totalTaskCount
            ) { all, pending, inProg, completed, total ->
                Quintuple(all, pending, inProg, completed, total)
            }.combine(
                combine(
                    repository.completedTaskCount,
                    repository.inProgressCount,
                    repository.getOverdueCount(now),
                    repository.getTasksDueSoon(now, tomorrow),
                    repository.allSubjects
                ) { compCount, inProgCount, overdue, dueSoon, subjects ->
                    Quintuple(compCount, inProgCount, overdue, dueSoon, subjects)
                }
            ) { a, b ->
                TaskUiState(
                    allTasks        = a.first,
                    pendingTasks    = a.second,
                    inProgressTasks = a.third,
                    completedTasks  = a.fourth,
                    totalCount      = a.fifth,
                    completedCount  = b.first,
                    inProgressCount = b.second,
                    overdueCount    = b.third,
                    dueSoonTasks    = b.fourth,
                    allSubjects     = b.fifth
                )
            }.collect { _uiState.value = it }
        }
    }

    // ── CRUD ──────────────────────────────────────────────────────────────────
    fun addTask(task: TaskEntity) {
        viewModelScope.launch {
            val id = repository.insertTask(task)
            notificationHelper.scheduleNotification(id.toInt(), task.title, task.deadlineMillis)
        }
    }

    fun updateTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.updateTask(task.copy(updatedAt = System.currentTimeMillis()))
            notificationHelper.cancelNotification(task.id)
            if (task.status != TaskStatus.COMPLETED) {
                notificationHelper.scheduleNotification(task.id, task.title, task.deadlineMillis)
            }
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            notificationHelper.cancelNotification(task.id)
            repository.deleteTask(task)
        }
    }

    // ── Module 4: Status cycling ──────────────────────────────────────────────
    fun cycleTaskStatus(task: TaskEntity) {
        viewModelScope.launch {
            val nextStatus = when (task.status) {
                TaskStatus.PENDING     -> TaskStatus.IN_PROGRESS
                TaskStatus.IN_PROGRESS -> TaskStatus.COMPLETED
                TaskStatus.COMPLETED   -> TaskStatus.PENDING
            }
            repository.updateTaskStatus(task.id, nextStatus)
            if (nextStatus == TaskStatus.COMPLETED) {
                notificationHelper.cancelNotification(task.id)
            }
        }
    }

    // Keep old toggleCompletion for backward compat
    fun toggleTaskCompletion(task: TaskEntity) = cycleTaskStatus(task)

    // ── Module 9: Search & Filter ─────────────────────────────────────────────
    fun setSearchQuery(query: String) {
        _filterState.value = _filterState.value.copy(searchQuery = query)
    }

    fun setFilterPriority(priority: Priority?) {
        _filterState.value = _filterState.value.copy(selectedPriority = priority)
    }

    fun setFilterSubject(subject: String?) {
        _filterState.value = _filterState.value.copy(selectedSubject = subject)
    }

    fun setFilterStatus(status: TaskStatus?) {
        _filterState.value = _filterState.value.copy(selectedStatus = status)
    }

    fun toggleOverdueFilter() {
        _filterState.value = _filterState.value.copy(
            showOverdueOnly = !_filterState.value.showOverdueOnly
        )
    }

    fun clearFilters() {
        _filterState.value = FilterState()
    }

    fun getTasksForDate(dateMillis: Long): Flow<List<TaskEntity>> {
        val startOfDay = dateMillis - (dateMillis % 86400000)
        val endOfDay   = startOfDay + 86400000 - 1
        return repository.getTasksForDateRange(startOfDay, endOfDay)
    }

    suspend fun getTaskById(id: Int): TaskEntity? = repository.getTaskById(id)
}

// Helper data class (Kotlin doesn't have built-in 5-tuple)
private data class Quintuple<A,B,C,D,E>(val first:A, val second:B, val third:C, val fourth:D, val fifth:E)
