package com.example.studyplannerpro

import androidx.room.Entity
import androidx.room.PrimaryKey

// ── Module 4: Task Status ────────────────────────────────────────────────────
// Three states a task can be in
enum class TaskStatus {
    PENDING,        // Not started
    IN_PROGRESS,    // Being worked on
    COMPLETED       // Done
}

// ── Module 1: Priority (unchanged) ──────────────────────────────────────────
enum class Priority {
    LOW, MEDIUM, HIGH
}

// ── Room Entity ──────────────────────────────────────────────────────────────
@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String,
    val subject: String,
    val deadlineMillis: Long,

    // Legacy boolean kept for backward compat; derived from status
    val isCompleted: Boolean = false,

    // NEW: replaces simple boolean with 3-state status
    val status: TaskStatus = TaskStatus.PENDING,

    val priority: Priority = Priority.MEDIUM,
    val createdAt: Long = System.currentTimeMillis(),

    // NEW: track when task was last updated (used in AI Insights)
    val updatedAt: Long = System.currentTimeMillis(),

    // NEW: estimated study hours (used in AI Insights & Analytics)
    val estimatedHours: Float = 1f,

    // NEW: tags/labels for Search & Filter (comma-separated string)
    val tags: String = ""
)
