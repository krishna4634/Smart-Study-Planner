package com.example.studyplannerpro

import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao) {

    // ── Streams (Flow) ───────────────────────────────────────────────────────
    val allTasks: Flow<List<TaskEntity>>       = taskDao.getAllTasks()
    val pendingTasks: Flow<List<TaskEntity>>   = taskDao.getPendingTasks()
    val inProgressTasks: Flow<List<TaskEntity>>= taskDao.getInProgressTasks()
    val completedTasks: Flow<List<TaskEntity>> = taskDao.getCompletedTasks()
    val totalTaskCount: Flow<Int>              = taskDao.getTotalTaskCount()
    val completedTaskCount: Flow<Int>          = taskDao.getCompletedTaskCount()
    val inProgressCount: Flow<Int>             = taskDao.getInProgressCount()
    val allSubjects: Flow<List<String>>        = taskDao.getAllSubjects()

    fun getOverdueCount(now: Long): Flow<Int> = taskDao.getOverdueCount(now)
    fun getTasksDueSoon(now: Long, tomorrow: Long): Flow<List<TaskEntity>> =
        taskDao.getTasksDueSoon(now, tomorrow)

    // ── Single task ──────────────────────────────────────────────────────────
    suspend fun getTaskById(id: Int): TaskEntity? = taskDao.getTaskById(id)

    // ── CRUD ─────────────────────────────────────────────────────────────────
    suspend fun insertTask(task: TaskEntity): Long = taskDao.insertTask(task)
    suspend fun updateTask(task: TaskEntity)       = taskDao.updateTask(task)
    suspend fun deleteTask(task: TaskEntity)       = taskDao.deleteTask(task)
    suspend fun deleteTaskById(id: Int)            = taskDao.deleteTaskById(id)

    suspend fun updateTaskStatus(id: Int, status: TaskStatus) {
        taskDao.updateTaskStatus(
            id          = id,
            status      = status,
            isCompleted = status == TaskStatus.COMPLETED,
            updatedAt   = System.currentTimeMillis()
        )
    }

    // ── Search & Filter ──────────────────────────────────────────────────────
    fun searchTasks(query: String): Flow<List<TaskEntity>> = taskDao.searchTasks(query)
    fun getTasksByPriority(priority: Priority): Flow<List<TaskEntity>> =
        taskDao.getTasksByPriority(priority)
    fun getTasksBySubject(subject: String): Flow<List<TaskEntity>> =
        taskDao.getTasksBySubject(subject)
    fun getTasksForDateRange(start: Long, end: Long): Flow<List<TaskEntity>> =
        taskDao.getTasksForDateRange(start, end)
}
