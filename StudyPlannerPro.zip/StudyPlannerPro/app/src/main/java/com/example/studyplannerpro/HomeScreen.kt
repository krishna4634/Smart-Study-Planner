package com.example.studyplannerpro

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studyplannerpro.ui.theme.AppColors
import java.text.SimpleDateFormat
import java.util.*

fun TaskStatus.label() = taskStatusLabel(this)
fun TaskStatus.color() = taskStatusColor(this)
fun TaskStatus.statusIcon(): ImageVector = when (this) {
    TaskStatus.PENDING -> Icons.Default.RadioButtonUnchecked
    TaskStatus.IN_PROGRESS -> Icons.Default.Autorenew
    TaskStatus.COMPLETED -> Icons.Default.CheckCircle
}
fun TaskStatus.next() = when (this) {
    TaskStatus.PENDING -> TaskStatus.IN_PROGRESS
    TaskStatus.IN_PROGRESS -> TaskStatus.COMPLETED
    TaskStatus.COMPLETED -> TaskStatus.PENDING
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: TaskViewModel, isDarkMode: Boolean, onToggleDarkMode: () -> Unit,
    onAddTask: () -> Unit, onEditTask: (Int) -> Unit,
    onCalendarView: () -> Unit, onProgressView: () -> Unit
) {
    val uiState       by viewModel.uiState.collectAsState()
    val filterState   by viewModel.filterState.collectAsState()
    val filteredTasks by viewModel.filteredTasks.collectAsState()
    var selectedTab   by remember { mutableIntStateOf(0) }
    var deleteTarget  by remember { mutableStateOf<TaskEntity?>(null) }
    var showFilters   by remember { mutableStateOf(false) }
    var searchQuery   by remember { mutableStateOf(filterState.searchQuery) }

    val tabTasks = when (selectedTab) {
        1 -> filteredTasks.filter { it.status == TaskStatus.PENDING }
        2 -> filteredTasks.filter { it.status == TaskStatus.IN_PROGRESS }
        3 -> filteredTasks.filter { it.status == TaskStatus.COMPLETED }
        else -> filteredTasks
    }
    val hasFilters = filterState.selectedPriority != null || filterState.selectedSubject != null ||
            filterState.selectedStatus != null || filterState.showOverdueOnly

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                TopAppBar(
                    title = { Text("My Tasks", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = onToggleDarkMode) {
                            Icon(if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode, null)
                        }
                        BadgedBox(badge = { if (hasFilters) Badge {} }) {
                            IconButton(onClick = { showFilters = true }) {
                                Icon(Icons.Default.FilterList, null)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
                )
                // Search bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it; viewModel.setSearchQuery(it) },
                    placeholder = { Text("Search tasks…", fontSize = 14.sp) },
                    singleLine = true, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    leadingIcon = { Icon(Icons.Default.Search, null, modifier = Modifier.size(18.dp)) },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) IconButton({ searchQuery = ""; viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Clear, null, modifier = Modifier.size(18.dp))
                        }
                    }
                )
                // Tabs
                ScrollableTabRow(selectedTabIndex = selectedTab, containerColor = MaterialTheme.colorScheme.background,
                    edgePadding = 16.dp, divider = {}) {
                    listOf("All", "Pending", "In Progress", "Done").forEachIndexed { i, lbl ->
                        Tab(selected = selectedTab == i, onClick = { selectedTab = i },
                            text = { Text(lbl, fontSize = 13.sp) })
                    }
                }
                Divider(color = MaterialTheme.colorScheme.outline.copy(0.3f))
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAddTask, containerColor = MaterialTheme.colorScheme.primary) {
                Icon(Icons.Default.Add, null, tint = Color.White)
            }
        }
    ) { pv ->
        if (tabTasks.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(pv), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (hasFilters || searchQuery.isNotBlank()) "🔍" else "📋", fontSize = 56.sp)
                    Spacer(Modifier.height(12.dp))
                    Text(if (hasFilters || searchQuery.isNotBlank()) "No matches found" else "No tasks yet",
                        fontSize = 18.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                    Text("Tap + to add a task", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(pv),
                contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tabTasks, key = { it.id }) { task ->
                    SimpleTaskCard(task,
                        onEdit    = { onEditTask(task.id) },
                        onDelete  = { deleteTarget = task },
                        onCycle   = { viewModel.cycleTaskStatus(task) })
                }
                item { Spacer(Modifier.height(72.dp)) }
            }
        }
    }

    deleteTarget?.let { task ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete task?") },
            text  = { Text("\"${task.title}\" will be removed.") },
            confirmButton = {
                Button(onClick = { viewModel.deleteTask(task); deleteTarget = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
            },
            dismissButton = { OutlinedButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }

    if (showFilters) {
        SimpleFilterSheet(uiState, filterState, viewModel) { showFilters = false }
    }
}

@Composable
fun SimpleTaskCard(task: TaskEntity, onEdit: () -> Unit, onDelete: () -> Unit, onCycle: () -> Unit) {
    val pColor  = priorityColor(task.priority)
    val sColor  = taskStatusColor(task.status)
    val isOver  = task.deadlineMillis < System.currentTimeMillis() && task.status != TaskStatus.COMPLETED
    val dateFmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
    val isDone  = task.status == TaskStatus.COMPLETED

    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(if (isDone) 0.dp else 2.dp)) {
        Row(Modifier.fillMaxWidth()) {
            // Priority strip
            Box(Modifier.width(4.dp).fillMaxHeight().background(pColor))
            Column(Modifier.padding(12.dp).weight(1f)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(task.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                            textDecoration = if (isDone) TextDecoration.LineThrough else null,
                            color = if (isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (task.subject.isNotBlank())
                            Text(task.subject, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.error)
                    }
                }

                if (task.description.isNotBlank()) {
                    Text(task.description, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
                }

                Spacer(Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, null, modifier = Modifier.size(12.dp),
                        tint = if (isOver) AppColors.Red500 else MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.width(3.dp))
                    Text(dateFmt.format(Date(task.deadlineMillis)), fontSize = 11.sp,
                        color = if (isOver) AppColors.Red500 else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (isOver) {
                        Spacer(Modifier.width(6.dp))
                        Box(Modifier.clip(RoundedCornerShape(4.dp)).background(AppColors.Red100).padding(horizontal = 5.dp, vertical = 1.dp)) {
                            Text("OVERDUE", fontSize = 9.sp, color = AppColors.Red600, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    // Status chip — tap to cycle
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(sColor.copy(0.12f))
                        .clickable { onCycle() }.padding(horizontal = 8.dp, vertical = 4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(task.status.statusIcon(), null, modifier = Modifier.size(12.dp), tint = sColor)
                            Spacer(Modifier.width(3.dp))
                            Text(task.status.label(), fontSize = 10.sp, color = sColor, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleFilterSheet(uiState: TaskUiState, filterState: FilterState, viewModel: TaskViewModel, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)) {
        Column(Modifier.padding(20.dp).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Filter Tasks", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (filterState.selectedPriority != null || filterState.selectedStatus != null || filterState.selectedSubject != null || filterState.showOverdueOnly)
                    TextButton(onClick = viewModel::clearFilters) { Text("Clear All", color = MaterialTheme.colorScheme.error) }
            }

            Text("Priority", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Priority.values().forEach { p ->
                    val sel = filterState.selectedPriority == p
                    FilterChip(selected = sel, onClick = { viewModel.setFilterPriority(if (sel) null else p) },
                        label = { Text("${priorityEmoji(p)} ${p.name}") })
                }
            }

            Text("Status", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TaskStatus.values().forEach { s ->
                    val sel = filterState.selectedStatus == s
                    FilterChip(selected = sel, onClick = { viewModel.setFilterStatus(if (sel) null else s) },
                        label = { Text(s.label()) })
                }
            }

            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Overdue only", fontSize = 14.sp)
                Switch(checked = filterState.showOverdueOnly, onCheckedChange = { viewModel.toggleOverdueFilter() })
            }

            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Apply") }
        }
    }
}
