package com.example.studyplannerpro

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// Holds the state of the auth screens
data class AuthUiState(
    val isLoggedIn: Boolean = false,
    val loggedInUser: UserEntity? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class AuthViewModel(application: Application) : AndroidViewModel(application) {

    private val userDao: UserDao = AppDatabase.getDatabase(application).userDao()

    // SharedPreferences key for keeping user logged in across app restarts
    private val prefs = application.getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    init {
        // Auto-login if a session was saved
        val savedUsername = prefs.getString("logged_in_username", null)
        if (savedUsername != null) {
            viewModelScope.launch {
                val user = userDao.getUserByUsername(savedUsername)
                if (user != null) {
                    _uiState.value = AuthUiState(isLoggedIn = true, loggedInUser = user)
                }
            }
        }
    }

    // ─── Register ───────────────────────────────────────────────────────────────
    fun register(fullName: String, username: String, password: String, confirmPassword: String) {
        // Basic validation
        if (fullName.isBlank() || username.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "All fields are required.")
            return
        }
        if (username.length < 3) {
            _uiState.value = _uiState.value.copy(errorMessage = "Username must be at least 3 characters.")
            return
        }
        if (password.length < 4) {
            _uiState.value = _uiState.value.copy(errorMessage = "Password must be at least 4 characters.")
            return
        }
        if (password != confirmPassword) {
            _uiState.value = _uiState.value.copy(errorMessage = "Passwords do not match.")
            return
        }

        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            // Check duplicate username
            val exists = userDao.usernameExists(username.trim())
            if (exists > 0) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Username \"${username.trim()}\" is already taken."
                )
                return@launch
            }

            val newUser = UserEntity(
                fullName = fullName.trim(),
                username = username.trim().lowercase(),
                password = password          // plain text – fine for BCA project
            )
            userDao.registerUser(newUser)
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                successMessage = "Account created! Please log in."
            )
        }
    }

    // ─── Login ───────────────────────────────────────────────────────────────────
    fun login(username: String, password: String) {
        if (username.isBlank() || password.isBlank()) {
            _uiState.value = _uiState.value.copy(errorMessage = "Enter username and password.")
            return
        }

        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)

        viewModelScope.launch {
            val user = userDao.loginUser(username.trim().lowercase(), password)
            if (user != null) {
                // Save session
                prefs.edit().putString("logged_in_username", user.username).apply()
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isLoggedIn = true,
                    loggedInUser = user
                )
            } else {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Incorrect username or password."
                )
            }
        }
    }

    // ─── Logout ──────────────────────────────────────────────────────────────────
    fun logout() {
        prefs.edit().remove("logged_in_username").apply()
        _uiState.value = AuthUiState(isLoggedIn = false)
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────────
    fun clearMessages() {
        _uiState.value = _uiState.value.copy(errorMessage = null, successMessage = null)
    }
}
