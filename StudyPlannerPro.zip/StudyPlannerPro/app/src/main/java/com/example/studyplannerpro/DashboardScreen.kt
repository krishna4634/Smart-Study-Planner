package com.example.studyplannerpro

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.studyplannerpro.ui.theme.AppColors
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    authViewModel: AuthViewModel, taskViewModel: TaskViewModel,
    isDarkMode: Boolean, onToggleDarkMode: () -> Unit,
    onAddTask: () -> Unit, onViewTasks: () -> Unit,
    onCalendar: () -> Unit, onProgress: () -> Unit,
    onAiInsights: () -> Unit, onLogout: () -> Unit
) {
    val auth  by authViewModel.uiState.collectAsState()
    val tasks by taskViewModel.uiState.collectAsState()
    var showLogoutDialog by remember { mutableStateOf(false) }

    val user    = auth.loggedInUser
    val total   = tasks.totalCount
    val done    = tasks.completedCount
    val inProg  = tasks.inProgressCount
    val overdue = tasks.overdueCount
    val prog    = if (total > 0) done.toFloat() / total else 0f
    val initial = (user?.fullName?.firstOrNull() ?: "S").toString().uppercase()

    val greeting = remember {
        when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
            in 0..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening"
        }
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
    ) {
        // ── Top bar ──────────────────────────────────────────────────────────
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(top = 52.dp, bottom = 8.dp),
            Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center) {
                    Text(initial, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 18.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("$greeting, ${user?.fullName?.split(" ")?.firstOrNull() ?: "Student"}!",
                        fontWeight = FontWeight.SemiBold, fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onBackground)
                    Text(SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date()),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row {
                IconButton(onClick = onToggleDarkMode) {
                    Icon(if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                        null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { showLogoutDialog = true }) {
                    Icon(Icons.Default.Logout, null, tint = MaterialTheme.colorScheme.error)
                }
            }
        }

        // ── Progress card ─────────────────────────────────────────────────────
        Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
            elevation = CardDefaults.cardElevation(4.dp)) {
            Column(Modifier.padding(20.dp)) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("Study Progress", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Color.White)
                    Text("${(prog * 100).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White.copy(0.9f))
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                    color = Color.White, trackColor = Color.White.copy(0.3f))
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                    ProgStat("$total", "Total")
                    ProgStat("$done", "Done")
                    ProgStat("$inProg", "In Progress")
                    ProgStat("$overdue", "Overdue")
                }
            }
        }

        // ── Stat row ──────────────────────────────────────────────────────────
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MiniStat("$done", "Done", AppColors.Green500, AppColors.Green100, Modifier.weight(1f))
            MiniStat("$inProg", "In Prog", AppColors.Primary500, AppColors.Primary100, Modifier.weight(1f))
            MiniStat("$overdue", "Late", AppColors.Red500, AppColors.Red100, Modifier.weight(1f))
        }

        // ── Due soon ──────────────────────────────────────────────────────────
        if (tasks.dueSoonTasks.isNotEmpty()) {
            Text("Due Soon", fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(tasks.dueSoonTasks) { task ->
                    Card(Modifier.width(180.dp), shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = AppColors.Amber100),
                        elevation = CardDefaults.cardElevation(2.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(task.title, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                                color = AppColors.TextDark, maxLines = 2)
                            Spacer(Modifier.height(4.dp))
                            Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(task.deadlineMillis)),
                                fontSize = 11.sp, color = AppColors.Amber600)
                        }
                    }
                }
            }
        }

        // ── Quick actions ─────────────────────────────────────────────────────
        Text("Quick Actions", fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))

        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionBtn("Add Task", Icons.Default.Add, MaterialTheme.colorScheme.primary, onAddTask, Modifier.weight(1f))
                ActionBtn("My Tasks", Icons.Default.List, MaterialTheme.colorScheme.secondary, onViewTasks, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionBtn("Calendar", Icons.Default.CalendarToday, AppColors.Amber500, onCalendar, Modifier.weight(1f))
                ActionBtn("Progress", Icons.Default.BarChart, AppColors.Red500, onProgress, Modifier.weight(1f))
            }
            ActionBtn("AI Insights", Icons.Default.AutoAwesome, MaterialTheme.colorScheme.primary, onAiInsights, Modifier.fillMaxWidth())
        }

        // AI Insight preview
        val insight = remember(tasks.allTasks) { generateInsights(tasks.allTasks).firstOrNull() }
        insight?.let { i ->
            Card(Modifier.fillMaxWidth().padding(16.dp).clickable { onAiInsights() },
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(i.emoji, fontSize = 26.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(i.title, fontWeight = FontWeight.Medium, fontSize = 13.sp, maxLines = 1)
                        Text(i.message, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Sign Out?") },
            text  = { Text("You'll be returned to the login screen.") },
            confirmButton = {
                Button(onClick = { showLogoutDialog = false; authViewModel.logout(); onLogout() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Sign Out") }
            },
            dismissButton = { OutlinedButton(onClick = { showLogoutDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable fun ProgStat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
        Text(label, fontSize = 10.sp, color = Color.White.copy(0.8f))
    }
}

@Composable fun MiniStat(value: String, label: String, color: Color, bg: Color, modifier: Modifier) {
    Card(modifier.height(68.dp), shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = color)
            Text(label, fontSize = 10.sp, color = color.copy(0.8f))
        }
    }
}

@Composable fun ActionBtn(label: String, icon: ImageVector, color: Color, onClick: () -> Unit, modifier: Modifier) {
    Card(modifier.height(68.dp).clickable { onClick() }, shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)) {
        Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(color.copy(0.12f)),
                contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text(label, fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
        }
    }
}
