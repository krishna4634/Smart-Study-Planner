package com.example.studyplannerpro

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTaskScreen(viewModel: TaskViewModel, taskId: Int?, onBack: () -> Unit) {
    val ctx   = LocalContext.current
    val scope = rememberCoroutineScope()
    val isEdit = taskId != null

    var title       by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var subject     by remember { mutableStateOf("") }
    var tags        by remember { mutableStateOf("") }
    var priority    by remember { mutableStateOf(Priority.MEDIUM) }
    var status      by remember { mutableStateOf(TaskStatus.PENDING) }
    var estHours    by remember { mutableStateOf("1") }
    var deadline    by remember { mutableStateOf(Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 1) }) }
    var loading     by remember { mutableStateOf(isEdit) }
    var titleError  by remember { mutableStateOf(false) }

    LaunchedEffect(taskId) {
        if (taskId != null) {
            viewModel.getTaskById(taskId)?.let { t ->
                title = t.title; description = t.description; subject = t.subject; tags = t.tags
                priority = t.priority; status = t.status; estHours = t.estimatedHours.toString()
                deadline = Calendar.getInstance().apply { timeInMillis = t.deadlineMillis }
            }
            loading = false
        }
    }

    fun pickDate() = DatePickerDialog(ctx, { _, y, m, d ->
        deadline = Calendar.getInstance().apply {
            set(y, m, d, deadline.get(Calendar.HOUR_OF_DAY), deadline.get(Calendar.MINUTE))
        }
    }, deadline.get(Calendar.YEAR), deadline.get(Calendar.MONTH), deadline.get(Calendar.DAY_OF_MONTH)).show()

    fun pickTime() = TimePickerDialog(ctx, { _, h, min ->
        deadline = Calendar.getInstance().apply { timeInMillis = deadline.timeInMillis; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, min) }
    }, deadline.get(Calendar.HOUR_OF_DAY), deadline.get(Calendar.MINUTE), false).show()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text(if (isEdit) "Edit Task" else "Add Task", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { pv ->
        if (loading) {
            Box(Modifier.fillMaxSize().padding(pv), Alignment.Center) { CircularProgressIndicator() }
        } else {
            Column(Modifier.fillMaxSize().padding(pv).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)) {

                // Title
                OutlinedTextField(title, { title = it; titleError = false },
                    label = { Text("Task Title *") }, isError = titleError,
                    supportingText = { if (titleError) Text("Title is required", color = MaterialTheme.colorScheme.error) },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences))

                // Description
                OutlinedTextField(description, { description = it },
                    label = { Text("Description (optional)") },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    minLines = 2, maxLines = 4)

                // Subject + hours
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(subject, { subject = it }, label = { Text("Subject") },
                        modifier = Modifier.weight(2f), shape = RoundedCornerShape(12.dp))
                    OutlinedTextField(estHours, { if (it.isEmpty() || it.toFloatOrNull() != null) estHours = it },
                        label = { Text("Hrs") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }

                // Tags
                OutlinedTextField(tags, { tags = it }, label = { Text("Tags (comma-separated)") },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                    placeholder = { Text("exam, chapter1", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.6f)) })

                // Priority
                Text("Priority", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Priority.values().forEach { p ->
                        val sel = priority == p
                        val pc  = priorityColor(p)
                        Box(Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (sel) pc.copy(0.18f) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { priority = p },
                            contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(priorityEmoji(p), fontSize = 16.sp)
                                Text(p.name, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = if (sel) pc else MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                // Status
                Text("Status", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TaskStatus.values().forEach { s ->
                        val sel = status == s
                        val sc  = taskStatusColor(s)
                        Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (sel) sc.copy(0.18f) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { status = s },
                            contentAlignment = Alignment.Center) {
                            Text(taskStatusLabel(s), fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                color = if (sel) sc else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                // Deadline
                Text("Deadline", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = ::pickDate, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.CalendarToday, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(deadline.time), fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = ::pickTime, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.AccessTime, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(deadline.time), fontSize = 13.sp)
                    }
                }

                Spacer(Modifier.height(4.dp))

                Button(
                    onClick = {
                        if (title.isBlank()) { titleError = true; return@Button }
                        scope.launch {
                            val task = TaskEntity(
                                id = taskId ?: 0, title = title.trim(), description = description.trim(),
                                subject = subject.trim(), tags = tags.trim(), priority = priority, status = status,
                                isCompleted = status == TaskStatus.COMPLETED,
                                estimatedHours = estHours.toFloatOrNull() ?: 1f,
                                deadlineMillis = deadline.timeInMillis, updatedAt = System.currentTimeMillis()
                            )
                            if (isEdit) viewModel.updateTask(task) else viewModel.addTask(task)
                            onBack()
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(if (isEdit) Icons.Default.Save else Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (isEdit) "Update Task" else "Save Task", fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
