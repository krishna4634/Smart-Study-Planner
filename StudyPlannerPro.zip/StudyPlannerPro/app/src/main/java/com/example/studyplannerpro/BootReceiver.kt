package com.example.studyplannerpro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val scope = CoroutineScope(Dispatchers.IO)
            scope.launch {
                val db = AppDatabase.getDatabase(context)
                val tasks = db.taskDao().getPendingTasks().first()
                val notificationHelper = NotificationHelper(context)
                tasks.forEach { task ->
                    if (task.deadlineMillis > System.currentTimeMillis()) {
                        notificationHelper.scheduleNotification(
                            taskId = task.id,
                            taskTitle = task.title,
                            deadlineMillis = task.deadlineMillis
                        )
                    }
                }
            }
        }
    }
}
