package com.example.studyplannerpro

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.studyplannerpro.ui.theme.AppColors

object DS {
    val cardDark  = Brush.verticalGradient(listOf(AppColors.Surface800, AppColors.Surface700))
    val cardLight = Brush.verticalGradient(listOf(Color.White, AppColors.LightCard2))

    val primary  = Brush.horizontalGradient(listOf(AppColors.Primary600, AppColors.Primary500))
    val danger   = Brush.horizontalGradient(listOf(AppColors.Red600, AppColors.Red500))
    val success  = Brush.horizontalGradient(listOf(AppColors.Green600, AppColors.Green500))
    val warning  = Brush.horizontalGradient(listOf(AppColors.Amber600, AppColors.Amber500))
    val progressBar = Brush.horizontalGradient(listOf(AppColors.Primary500, AppColors.Primary400))
}

fun Modifier.cardShadow(elevation: Dp = 4.dp, r: Dp = 16.dp): Modifier =
    shadow(elevation, RoundedCornerShape(r), ambientColor = Color.Black.copy(0.08f), spotColor = Color.Black.copy(0.12f))

fun taskStatusColor(status: TaskStatus) = when (status) {
    TaskStatus.PENDING     -> AppColors.Amber500
    TaskStatus.IN_PROGRESS -> AppColors.Primary500
    TaskStatus.COMPLETED   -> AppColors.Green500
}
fun taskStatusLabel(status: TaskStatus) = when (status) {
    TaskStatus.PENDING     -> "Pending"
    TaskStatus.IN_PROGRESS -> "In Progress"
    TaskStatus.COMPLETED   -> "Done"
}
fun priorityColor(priority: Priority) = when (priority) {
    Priority.HIGH   -> AppColors.Red500
    Priority.MEDIUM -> AppColors.Amber500
    Priority.LOW    -> AppColors.Green500
}
fun priorityEmoji(priority: Priority) = when (priority) {
    Priority.HIGH -> "🔴"; Priority.MEDIUM -> "🟡"; Priority.LOW -> "🟢"
}

